<?php
namespace Infobeans\Label\Controller\Index;


class Index extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        die("Hello 😉 - Infobeans\\Label\\Controller\\Index\\Index - execute() method");
    }
}
